# Traffic > 2025-04-10 11:07am
https://universe.roboflow.com/borosa/traffic-gnknb

Provided by a Roboflow user
License: CC BY 4.0

